# PlantMegaPack mikexxx port (Forge 1.20.1)
Upload this folder (or the zip) to a GitHub repo -> Actions tab -> "build-jar" -> download the jar artifact.
Honeycomb on a plant = waxed (stops growing). Axe removes wax. Bone meal = +1 growth stage.

Added in this revision:
- Planters (59), flower pots (32), wall brackets (26 incl. 1.7.10 stone/gem ones), bamboo poles (9), bamboo walls (9),
  fruitwood bark, potting table (opens a 3x3 crafting grid).
- 241 crafting recipes converted from the 1.12.2 version (+ item tags food_vegetable/fruit/berry/nut/rice/bread/mushroom).
- Latin names for all species/cultivar plants (shown as grey italic tooltip).

Not ported: world generation, advancements, trellis / trellis tower (no assets in the 1.12.2 jar), curled brackets, cactus spike items.

Rev 3:
- Removed duplicate plants (same texture, different name): kept the specific 1.7.10 cultivar names, kept 1.12.2 colours only where 1.7.10 has none.
  Flowers are sorted by plant, then rainbow order (dark red -> red -> coral -> orange -> yellow -> green -> cyan -> blue -> royal -> purple -> magenta -> pink -> white).
- Tall plants are separate blocks: 1.12.2 3-segment plants = Bottom / Middle / Top blocks, 2-block plants = Bottom / Top blocks,
  1.7.10 plants with 6/8/10 stage textures = one block per stage (Stage 1..n). Plants with 2-5 stages still grow with bone meal.
- Epiphytes (18) are wall-mounted blocks that attach to the side of logs/blocks.
